# ⚡ MehburAI — Hibrit Çevrim İçi & Çevrim Dışı Masaüstü Yapay Zeka

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10%2B-00F0FF?style=for-the-badge&logo=python&logoColor=black" alt="Python Version" />
  <img src="https://img.shields.io/badge/GUI-CustomTkinter-008B99?style=for-the-badge" alt="CustomTkinter" />
  <img src="https://img.shields.io/badge/AI-Google_Gemini-FF3366?style=for-the-badge&logo=google" alt="Gemini AI" />
  <img src="https://img.shields.io/badge/Theme-Neon_Cyan_%26_Black-07070B?style=for-the-badge" alt="Neon Theme" />
  <img src="https://img.shields.io/badge/License-MIT-00FF88?style=for-the-badge" alt="License" />
</p>

**MehburAI**, internet bağlantısını dinamik olarak algılayan, çevrim içiyken **Google Gemini API** ve güvenilir kaynaklar (**Wikipedia OpenSearch & REST v1**) üzerinden soruları yanıtlayıp otomatik olarak yerel hafızasına kaydeden, çevrim dışıyken ise **Türkçe Morfolojik Semantik Benzerlik Motoru** ile hafızasındaki bilgileri hatasız getiren modern bir masaüstü yapay zeka asistanıdır.

---

## 🌟 Temel Özellikler

- 🌐 **Sıfır Gecikmeli Ağ Algılama:** Cloudflare (`1.1.1.1`) DNS socket kontrolü ile gerçek zamanlı canlı bağlantı durumu (`🟢 Çevrimiçi` / `🔴 Çevrimdışı`).
- 🧠 **Öğrenen Kalıcı Bellek (SQLite):** Çevrim içiyken sorulan her soru ve cevabı hafızaya kaydeder (*"Eğer bu soru sorulursa bu cevabı ver"*).
- 🔍 **Türkçe Semantik Eşleme:** Soru farklı kelimeler veya eklerle sorulsa bile (Karakter N-Gram + Kök Jaccard + Token Kosinüs Benzerliği) hafızadaki doğru cevabı bulur.
- ⚡ **Neon Cyan & Siyah Masaüstü Arayüzü:** CustomTkinter ile donmayan asenkron arka plan thread mimarisi.
- 💻 **Gerçek Bilgisayar Erişimi:** Sadece sabit birkaç uygulama değil — *herhangi bir programı* adından bulup açar (Spotify, Word, Chrome, Ayarlar, Kamera…), klasör açar, dosya arar, klasör/dosya oluşturur, **ses / parlaklık** ayarlar, ekranı kilitler, uyku moduna alır, **ekran görüntüsü** alır ve (onaylı, iptal edilebilir) **kapatma / yeniden başlatma** komutlarını çalıştırır.
- 🤬 **Yazım Hatası Toleranslı Küfür Filtresi:** `orospo`, `aptl`, `çomarr` gibi bilerek/yanlışlıkla bozuk yazılmış hakaretleri de yakalar; `solak`, `yürek`, `sülük` gibi masum kelimelere bulaşmaz.
- 🛡️ **Güvenlik Modu (Yetkisiz Erişim Alarmı):** Ayarlardan korumalı klasör/program yolları, bir şifre ve Telegram bilgileri girilir. Korunan yol **kapalıyken açıldığında** MehburAI tüm ekranı karartıp **şifre sorar**; şifre yanlış girilir ya da ekran kapatılırsa açılan program/klasör kapatılır, web kameradan fotoğraf çekilip cihaz sahibine **Telegram'dan** (`MehburAI (Telegram)` botu) gönderilir ve kişiye *"fotoğrafınız çekildi, kameraya bakın gülümseyin :D"* yazılır. Tepside açık kalan (Telegram/WhatsApp gibi) programları da destekler; laptop uyku moduna geçip uyandığında birikmiş açılışlar için sormaz. Pencereyi kapatsan bile **sistem tepsisinde arka planda çalışır** ve istenirse **Windows açılışında otomatik başlar**. *(Gizli izleme değildir — şifre ekranı ve uyarı açıkça görünür.)*
- 😈 **Özel İsim Yanıtı:** *"Adın ne?"*, *"Kimsin?"* gibi sorulara *"Merhaba, ben MehburAI dünyayı ele geçireceğim"* şeklinde özel yanıt verir.
- 🔑 **Güvenli Ayarlar Paneli:** Gemini API anahtarınızı arayüz üzerinden kolayca ekleyebilir, güncelleyebilir veya silebilirsiniz.

---

## 🚀 Hızlı Başlangıç (Tek Tıkla Otomatik Kurulum)

### 1. Yöntem: `Setup_and_Run.bat` ile (Tavsiye Edilen)
Projeyi indirdikten sonra klasör içindeki **`Setup_and_Run.bat`** dosyasına çift tıklayın. 
* Otomatik olarak tüm kütüphaneleri kurar,
* Masaüstünüze `MehburAI` kısayolunu oluşturur,
* Yapay zekayı anında başlatır.

### 2. Yöntem: Manuel Terminal ile
```powershell
# 1. Projeyi klonlayın
git clone https://github.com/Mehbur07/MehburAI.git
cd MehburAI

# 2. Gerekli kütüphaneleri yükleyin
pip install -r requirements.txt

# 3. MehburAI'yi çalıştırın
python run_mehbur.py
```

---

## 📁 Proje Mimarisi

```
MehburAI/
├── config.py             # Neon Cyan tema sabitleri & ayar yöneticisi
├── network_manager.py    # Cloudflare 1.1.1.1 anlık ağ izleyici
├── memory_engine.py      # SQLite + Türkçe Morfolojik Semantik Bellek
├── ai_engine.py          # Wikipedia + Gemini REST (streamGenerateContent) + Karar Motoru + Küfür Filtresi
├── system_tools.py       # Program açma, dosya/klasör, ses/parlaklık, kilit/uyku, ekran görüntüsü, güç
├── security_guard.py     # 🛡️ Güvenlik Modu: korumalı yol izleme + kamera + Telegram alarmı
├── background.py         # 🛡️ Otomatik başlatma (Başlangıç kısayolu) + tek örnek kilidi
├── gui_app.py            # CustomTkinter Neon Cyan & Siyah Masaüstü GUI
├── requirements.txt      # Bağımlılıklar
├── run_mehbur.py         # Ana başlatıcı
├── Setup_and_Run.bat     # Tek tıkla otomatik kurucu & başlatıcı
└── data/
    └── mehbur_memory.db  # Kalıcı SQLite bellek veritabanı
```

---

## 📄 Lisans
Bu proje **MIT** lisansı altında geliştirilmiştir.
Geliştirici: **[Mehbur07 (Mehmet Burak ŞAHİN)](https://mehbur07.com)**
